# ConversationalAI-QAAutomation

## Overview
This project automates QA testing for conversational AI systems, including API and UI testing.

## Features
- API automation with Pytest + Requests
- UI automation with Selenium
- GitHub Actions CI/CD integration
- HTML reports for test runs

## Run Locally
```bash
pip install -r requirements.txt
pytest --html=reports/report.html --self-contained-html
```

## Folder Structure
```
tests/
  api/ - API test scripts
  ui/ - UI test scripts
config/ - API endpoints and credentials
data/ - test data
.github/workflows/ - CI/CD pipeline
```

## Future Enhancements
- Add Docker support
- Integrate with Jira for bug logging
- Add Allure Reports for detailed insights
