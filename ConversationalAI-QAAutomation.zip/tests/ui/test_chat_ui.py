from selenium import webdriver
from selenium.webdriver.common.by import By
import pytest

@pytest.fixture
def browser():
    driver = webdriver.Chrome()
    yield driver
    driver.quit()

def test_chat_ui_interaction(browser):
    browser.get("https://example-chatbot-ui.com")
    input_box = browser.find_element(By.ID, "chat-input")
    input_box.send_keys("Hello")
    browser.find_element(By.ID, "send-btn").click()
    reply = browser.find_element(By.CLASS_NAME, "bot-message").text
    assert "hello" in reply.lower()
