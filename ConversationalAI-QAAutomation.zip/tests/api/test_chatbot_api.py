import requests
import json
import pytest

with open('config/endpoints.json') as f:
    endpoints = json.load(f)

def test_chatbot_responds():
    payload = {"user_message": "Hi"}
    response = requests.post(endpoints["chat_api"], json=payload)
    assert response.status_code == 200
    data = response.json()
    assert "response" in data
    assert isinstance(data["response"], str)

def test_chatbot_latency():
    payload = {"user_message": "Order pizza"}
    response = requests.post(endpoints["chat_api"], json=payload)
    assert response.elapsed.total_seconds() < 2
